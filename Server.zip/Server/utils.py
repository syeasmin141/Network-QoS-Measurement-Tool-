import psycopg2
import pandas as pd

LAST_HOUR_QUERY = "select column_name from qosmetrics where date >= (NOW() - INTERVAL '1 hours' )"
LAST_HOUR_LOAD_QUERY = "select column_name from qosmetrics where date >= (NOW() - INTERVAL '1 hours') and load = 'load_type' "
LAST_50_THROUGHPUT_QUERY = "select bandwidth_download from qosmetrics where load = 'load_type'"
# LAST_HOUR_QUERY = "select column_name from qosmetrics"

class QueryTool:
    def __init__(self):
        self.connection = psycopg2.connect(database="vrqkllcv", user="vrqkllcv", password="TSrgnE6n95-8HRM7JqW7MvIpWEKqyIUb",
                              host="castor.db.elephantsql.com", port="5432")
        self.cursor = self.connection.cursor()

    # Query to get the total revenue for last 8 weeks..
    def get_last_hour_metrics(self, metric):
        self.cursor.execute(LAST_HOUR_QUERY.replace("column_name", metric))
        rows = self.cursor.fetchall()
        return rows

    # Query to get the total revenue for last 8 weeks..
    def get_last_hour_load_metrics(self, metric, load):
        self.cursor.execute(LAST_HOUR_LOAD_QUERY.replace("column_name", metric).replace("load_type", load))
        rows = self.cursor.fetchall()
        return rows

    def get_last_50(self, load):
        self.cursor.execute(LAST_50_THROUGHPUT_QUERY.replace("load_type", load))
        rows = self.cursor.fetchall()
        return rows

    def get_location_data(self):
        self.cursor.execute("select latitude, longitude, throughput_download from qosmetrics")
        rows = self.cursor.fetchall()
        processed_rows = []

        df = pd.DataFrame(rows)
        df = df.groupby([0, 1]).mean().reset_index().astype(float)
        for index, row in df.iterrows():
            processed_rows.append(row.tolist())
        return processed_rows

    def get_historic_data(self):
        self.cursor.execute("select * from qosmetrics")
        rows = self.cursor.fetchall()

        df = pd.DataFrame(rows,
                          columns=["bandwidth_download", "bandwidth_upload", "throughput_download", "throughput_upload",
                                   "latency_download", "latency_upload", "jitter_download", "jitter_upload",
                                   "packetloss_download", "packetloss_upload", "date", "latitude", "longitude", "load"])

        return df

