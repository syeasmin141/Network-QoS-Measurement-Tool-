from flask import Flask, request, jsonify, render_template
from utils import QueryTool
from pytz import timezone
from flask import send_file, send_from_directory
from datetime import datetime
import os
import geopy.distance
import numpy as np
import json
import time
import subprocess
import platform

server_url = "129.100.17.101"
param = '-n' if platform.system().lower()=='windows' else '-c'

server_coordinates = (42.9834, -81.233)
app = Flask(__name__, template_folder="templates")

@app.route('/get_latency', methods = ['POST'])
def get_latency():
    server_start_time = datetime.timestamp(datetime.now())
    return jsonify({"server_start_time": server_start_time})


@app.route('/get_latency_and_packet_loss', methods = ['POST'])
def get_latency_and_packet_loss():
    ping_result = subprocess.Popen(['ping', param, '3', server_url, '-l', '3'], stderr=subprocess.STDOUT,
                                       stdout=subprocess.PIPE).communicate()

    latency = float(ping_result[0].decode('utf-8').split("\n")[-2].split(" = ")[-1].split("/")[1])

    sent = int(ping_result[0].decode('utf-8').split("transmitted, ")[0].split("\n")[-1].split(" ")[0])
    recieved = int(ping_result[0].decode('utf-8').split("transmitted, ")[1].split(",")[0].split(" ")[0])

    packet_loss = 1 - (recieved / sent)
    return jsonify({"latency": latency, "packet_loss": packet_loss})


@app.route("/upload_file", methods=["POST"])
def upload_file():
    file = request.files["file"]
    del file
    return jsonify({"status": "complete"})

@app.route("/get_packet_loss", methods=["POST"])
def get_packet_loss():
    file1 = request.files["file"]

    file_byte_size = len(file1.read())

    return jsonify({"recieved_size": file_byte_size})

import os
@app.route("/download_packet_loss")
def download_packet_loss():
    return send_file("Download Files/image.jpg", mimetype='image')

@app.route('/download_historic_data')
def download_all_data():
    query = QueryTool()
    df = query.get_historic_data()
    df = df[["bandwidth_download", "bandwidth_upload", "throughput_download", "throughput_upload", "latency_download",
             "latency_upload", "jitter_download", "jitter_upload", "packetloss_download", "packetloss_upload", "date"]]
    try:
        os.remove("Data/historic.csv")
    except:
        pass

    df = df.set_index("date")
    df = df.tz_localize('UTC').tz_convert('US/Eastern')
    df.to_csv("Data/historic.csv")

    return send_file("Data/historic.csv", mimetype='text/csv',
                     attachment_filename='historic.csv',as_attachment=True)

"Download Files/ "
@app.route("/metrics")
def metrics():
    query = QueryTool()
    bandwidth_download = query.get_last_hour_metrics("bandwidth_download")
    bandwidth_download = [float(i[0]) for i in bandwidth_download]
    bandwidth_upload = query.get_last_hour_metrics("bandwidth_upload")
    bandwidth_upload = [float(i[0]) for i in bandwidth_upload]

    throughput_download = query.get_last_hour_metrics("throughput_download")
    throughput_download = [float(i[0]) for i in throughput_download]
    throughput_upload = query.get_last_hour_metrics("throughput_upload")
    throughput_upload = [float(i[0]) for i in throughput_upload]

    latency_download = query.get_last_hour_metrics("latency_download")
    latency_download = [float(i[0]) for i in latency_download]
    latency_upload = query.get_last_hour_metrics("latency_upload")
    latency_upload = [float(i[0]) for i in latency_upload]

    jitter_download = query.get_last_hour_metrics("jitter_download")
    jitter_download = [float(i[0]) for i in jitter_download]
    jitter_upload = query.get_last_hour_metrics("jitter_upload")
    jitter_upload = [float(i[0]) for i in jitter_upload]

    packetloss_download = query.get_last_hour_metrics("packetloss_download")
    packetloss_download = [int(100 * i[0]) for i in packetloss_download]
    packetloss_upload = query.get_last_hour_metrics("packetloss_upload")
    packetloss_upload = [int(100 * i[0]) for i in packetloss_upload]

    dates = query.get_last_hour_metrics("date")
    dates = [i[0].replace(tzinfo=timezone('UTC')).astimezone(tz=timezone('US/Eastern')).strftime("%Y-%m-%d %H:%M:%S") for i in dates]

    low_bandwidth_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("bandwidth_download", "low")]))
    medium_bandwidth_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("bandwidth_download", "medium")]))
    high_bandwidth_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("bandwidth_download", "high")]))

    low_bandwidth_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("bandwidth_upload", "low")]))
    medium_bandwidth_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("bandwidth_upload", "medium")]))
    high_bandwidth_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("bandwidth_upload", "high")]))

    low_throughput_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("throughput_download", "low")]))
    medium_throughput_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("throughput_download", "medium")]))
    high_throughput_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("throughput_download", "high")]))

    low_throughput_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("throughput_upload", "low")]))
    medium_throughput_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("throughput_upload", "medium")]))
    high_throughput_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("throughput_upload", "high")]))

    low_latency_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("latency_download", "low")]))
    medium_latency_download =float(np.mean([i[0] for i in query.get_last_hour_load_metrics("latency_download", "medium")]))
    high_latency_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("latency_download", "high")]))

    low_latency_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("latency_upload", "low")]))
    medium_latency_upload =float(np.mean([i[0] for i in query.get_last_hour_load_metrics("latency_upload", "medium")]))
    high_latency_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("latency_upload", "high")]))

    low_jitter_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("jitter_download", "low")]))
    medium_jitter_download =float(np.mean([i[0] for i in query.get_last_hour_load_metrics("jitter_download", "medium")]))
    high_jitter_download = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("jitter_download", "high")]))

    low_jitter_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("jitter_upload", "low")]))
    medium_jitter_upload =float(np.mean([i[0] for i in query.get_last_hour_load_metrics("jitter_upload", "medium")]))
    high_jitter_upload = float(np.mean([i[0] for i in query.get_last_hour_load_metrics("jitter_upload", "high")]))

    low_packetloss_download = float(np.mean([int(100 * i[0]) for i in query.get_last_hour_load_metrics("packetloss_download", "low")]))
    medium_packetloss_download = float(np.mean([int(100 * i[0]) for i in query.get_last_hour_load_metrics("packetloss_download", "medium")]))
    high_packetloss_download = float(np.mean([int(100 * i[0]) for i in query.get_last_hour_load_metrics("packetloss_download", "high")]))

    low_packetloss_upload = float(np.mean([int(100 * i[0]) for i in query.get_last_hour_load_metrics("packetloss_upload", "low")]))
    medium_packetloss_upload = float(np.mean([int(100 * i[0]) for i in query.get_last_hour_load_metrics("packetloss_upload", "medium")]))
    high_packetloss_upload = float(np.mean([int(100 * i[0]) for i in query.get_last_hour_load_metrics("packetloss_upload", "high")]))

    location_throughput = query.get_location_data()

    # location_throughput = [[geopy.distance.distance((float(row[0]), float(row[1])), server_coordinates).km, float(row[2])] for row in location_throughput]

    last_50_low = query.get_last_50("low")
    last_50_medium = query.get_last_50("medium")
    last_50_high = query.get_last_50("high")
    last_50_low = [float(i[0]) for i in last_50_low]
    last_50_medium = [float(i[0]) for i in last_50_medium]
    last_50_high = [float(i[0]) for i in last_50_high]

    if len(last_50_low) != 0:
        percentile_4g_low = round(np.mean(last_50_low))
    else:
        percentile_4g_low = 0

    if len(last_50_medium) != 0:
        percentile_4g_medium = round(np.mean(last_50_medium))
    else:
        percentile_4g_medium = 0

    if len(last_50_high) != 0:
        percentile_4g_high = round(np.mean(last_50_high))
    else:
        percentile_4g_high = 0

    last_50_labels_low = [i for i in range(1, len(last_50_low)+1)]
    last_50_labels_medium = [i for i in range(1, len(last_50_medium)+1)]
    last_50_labels_high = [i for i in range(1, len(last_50_high)+1)]

    last_50_low_5g = []
    last_50_low_4g = []
    for i in last_50_low:
        if i > percentile_4g_low:
            last_50_low_5g.append(i)
            last_50_low_4g.append(0)
        else:
            last_50_low_5g.append(0)
            last_50_low_4g.append(i)

    last_50_medium_5g = []
    last_50_medium_4g = []
    for i in last_50_medium:
        if i > percentile_4g_medium:
            last_50_medium_5g.append(i)
            last_50_medium_4g.append(0)
        else:
            last_50_medium_5g.append(0)
            last_50_medium_4g.append(i)



    last_50_high_5g = []
    last_50_high_4g = []
    for i in last_50_high:
        if i > percentile_4g_high:
            last_50_high_5g.append(i)
            last_50_high_4g.append(0)
        else:
            last_50_high_5g.append(0)
            last_50_high_4g.append(i)
    bandwidth_load_download = [low_bandwidth_download, medium_bandwidth_download, high_bandwidth_download]
    bandwidth_load_upload = [low_bandwidth_upload, medium_bandwidth_upload, high_bandwidth_upload]
    throughput_load_download = [low_throughput_download, medium_throughput_download, high_throughput_download]
    throughput_load_upload = [low_throughput_upload, medium_throughput_upload, high_throughput_upload]
    latency_load_download = [low_latency_download, medium_latency_download, high_latency_download]
    latency_load_upload = [low_latency_upload, medium_latency_upload, high_latency_upload]
    jitter_load_download = [low_jitter_download, medium_jitter_download, high_jitter_download]
    jitter_load_upload = [low_jitter_upload, medium_jitter_upload, high_jitter_upload]
    packetloss_load_download = [low_packetloss_download, medium_packetloss_download, high_packetloss_download]
    packetloss_load_upload = [low_packetloss_upload, medium_packetloss_upload, high_packetloss_upload]
    load_labels = ["Low Load", "Medium Load", "High Load"]



    for l in [bandwidth_load_download, bandwidth_load_upload, throughput_load_download, throughput_load_upload, latency_load_download, latency_load_upload, jitter_load_download, jitter_load_upload, packetloss_load_download, packetloss_load_upload]:
        for index, i in enumerate(l):
            if i == np.nan:
                l[index] = 0

    return render_template("metrics.html",
                           dates=dates,
                           bandwidth_download=bandwidth_download,
                           bandwidth_upload=bandwidth_upload,
                           throughput_download=throughput_download,
                           throughput_upload=throughput_upload,
                           latency_download=latency_download,
                           latency_upload=latency_upload,
                           jitter_download=jitter_download,
                           jitter_upload=jitter_upload,
                           packetloss_download=packetloss_download,
                           packetloss_upload=packetloss_upload,
                           bandwidth_load_download=bandwidth_load_download,
                           bandwidth_load_upload=bandwidth_load_upload,
                           throughput_load_download=throughput_load_download,
                           throughput_load_upload=throughput_load_upload,
                           latency_load_download=latency_load_download,
                           latency_load_upload=latency_load_upload,
                           jitter_load_download=jitter_load_download,
                           jitter_load_upload=jitter_load_upload,
                           packetloss_load_download=packetloss_load_download,
                           packetloss_load_upload=packetloss_load_upload,
                           load_labels=load_labels,
                           last_50_low_5g=last_50_low_5g,
                           last_50_low_4g=last_50_low_4g,
                           last_50_medium_5g=last_50_medium_5g,
                           last_50_medium_4g=last_50_medium_4g,
                           last_50_high_5g=last_50_high_5g,
                           last_50_high_4g=last_50_high_4g,
                           last_50_labels_low=last_50_labels_low,
                           last_50_labels_medium=last_50_labels_medium,
                           last_50_labels_high=last_50_labels_high,
                           percentile_4g_low=percentile_4g_low,
                           percentile_4g_medium=percentile_4g_medium,
                           percentile_4g_high=percentile_4g_high,
                           location_throughput=location_throughput)

if __name__ == '__main__':
    # app.run(host='0.0.0.0', debug=True)
    app.run(host='0.0.0.0')