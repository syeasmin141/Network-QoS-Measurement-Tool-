import requests
import json
import argparse
from multiprocessing import Process

def upload_file(file_path, server_url):
    """
    Upload a file to the server (file is not saved on server)
    :param file_path:

    :param server_url:
    :return:
    """
    files = {"file": open(file_path, "rb")}
    response = requests.post(server_url, files=files)

    return response

def download_file(file_path, server_url):
    data = {"file", file_path}
    response = requests.post(server_url, data=json.dumps(data))

    return "downloaded"

def run_upload(inp):
    upload_response = upload_file("Upload Files/4k image.jpg","http://129.100.17.101:5000//upload_file")
    upload_response = upload_file("Upload Files/image.jpg","http://129.100.17.101:5000//upload_file")
    upload_response = upload_file("Upload Files/excel.xlsx","http://129.100.17.101:5000//upload_file")
    upload_response = upload_file("Upload Files/word.docx","http://129.100.17.101:5000//upload_file")

def parse_args():
    parser = argparse.ArgumentParser(
        description="Sharing Files to the server"
    )

    parser.add_argument(
        "--load",
        type=str,
        default="low",
    )

    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    if args.load == "low":
        process_size = 1

    elif args.load == "medium":
        process_size = 2

    elif args.load == "high":
        process_size = 50

    while True:
        processes = []
        for i in range(process_size):
            p = Process(target=run_upload, args=(1, ))
            processes.append(p)

        for p in processes:
            p.start()
            p.join()

