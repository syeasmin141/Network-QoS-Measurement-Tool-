import random
import subprocess
import platform
import psycopg2
import psutil
import time
import requests
import numpy as np
import geocoder
import argparse
import speedtest
import json
import re
from datetime import datetime
from subprocess import Popen

param = '-n' if platform.system().lower()=='windows' else '-c'

# Connect to database
connection = psycopg2.connect(database="vrqkllcv", user="vrqkllcv", password="TSrgnE6n95-8HRM7JqW7MvIpWEKqyIUb",
                              host="castor.db.elephantsql.com", port="5432")
cursor = connection.cursor()
DOWNLOAD_BYTES_BITS = 33430
base_lat, base_lng = 42.9834, -81.233
# Create the table if it does not exist

cursor.execute("""
create table IF NOT EXISTS QOSMetrics(
bandwidth_download numeric,
bandwidth_upload numeric,
throughput_download numeric,
throughput_upload numeric,
latency_download numeric,
latency_upload numeric,
jitter_download numeric,
jitter_upload numeric,
packetloss_download numeric,
packetloss_upload numeric,
date timestamp DEFAULT now(),
latitude numeric,
longitude numeric,
load char(50)
);
""")

connection.commit()

def get_bandwidth():
    """
    This function uses speedtest api to get best internet speed (theoretical internet bandwidth).
    :return:
    """
    st = speedtest.Speedtest()
    return round(st.download() / 1000000, 2), round(st.upload() / 1000000, 2)

def calculate_throughput(old_throughput_download, old_throughput_upload):
    """
    This function calculates all bits sent and received on a network since the last recorded amount.
    :param old_bandwidth:

    :return:
    The difference between the last recorded throughput and the current one
    """
    new_throughput_download = psutil.net_io_counters().bytes_sent
    new_throughput_download = convert_to_megabits(new_throughput_download)

    new_throughput_upload = psutil.net_io_counters().bytes_recv
    new_throughput_upload = convert_to_megabits(new_throughput_upload)

    difference_download = new_throughput_download - old_throughput_download
    difference_upload = new_throughput_upload - old_throughput_upload

    return difference_download, difference_upload


def convert_to_megabits(number_of_bytes):
    """
    Converts bytes to megabits

    :param number_of_bytes:
    Number of given bytes

    :return:
    Converted amount of megabits
    """
    return number_of_bytes/100000

def get_latency(server_url):
    """
    This function will ping the server and record the amount of time for a response to be returned, this will record the
    amount of time for data to travel across the entire network

    :param server_url:
    Url to the server

    :return:
    time in milliseconds
    """
    start_time = datetime.timestamp(datetime.now())
    response = requests.post(server_url)

    mid_time = json.loads(response.content.decode("utf-8"))["server_start_time"]

    upload_latency = round(((mid_time - start_time) / 2), 2)
    end_time = time.time()

    download_latency = round((end_time - start_time), 2)

    return upload_latency, download_latency

def calculate_jitter(latencies):
    """
    This function calculates the jitter of the network by computing the variance in the latencies of a given time period

    :param latencies:
    List of all previous latencies in a given time period

    :return:
    jitter in milliseconds
    """
    return np.std(latencies)

def get_packet_loss(server_url):
    """
    This function pings the server and then reads the responses and calculates packet loss

    :param server_url:
    url of the server to ping

    :return:
    packet_loss
    """

    ping_result = subprocess.Popen(['ping', param, '4', server_url, '-l', '4'], stderr=subprocess.STDOUT,
                                   stdout=subprocess.PIPE).communicate()

    sent = int(ping_result[0].decode('utf-8').split("transmitted, ")[0].split("\n")[-1].split(" ")[0])

    recieved = int(ping_result[0].decode('utf-8').split("transmitted, ")[1].split(",")[0].split(" ")[0])

    lost = sent - recieved
    return int(lost)

def get_upload_packet_loss(server_url, file_name):
    #Load File
    files = {"file":open(file_name, "rb")}

    #Send file to server
    response = requests.post(server_url, files=files)

    #Return how many bytes were received on the server
    return json.loads(response.content.decode("utf-8"))["recieved_size"]


def get_download_packet_loss(server_url):
    #Get file from server
    response = requests.get(server_url)

    #Return how many bytes were downloaded
    return len(response.content)

# def get_latency_and_packet_loss(server_url):
#     #Get file from server
#     response = requests.post(server_url)
#     latency =json.loads(response.content.decode("utf-8"))["latency"]
#     packet_loss =json.loads(response.content.decode("utf-8"))["packet_loss"]
#     #Return how many bytes were downloaded
#     return latency, packet_loss

def get_latency_and_packet_loss(server_url):

    ping_result = subprocess.Popen(['ping', param, '3', "129.100.17.101", '-l', '3'], stderr=subprocess.STDOUT,
                                   stdout=subprocess.PIPE).communicate()
    latency = float(re.findall("\d+",ping_result[0].decode('utf-8').split("\n")[-2].split(" = ")[-1])[0])
    # sent = int(re.findall("\d+",ping_result[0].decode('utf-8').split("transmitted, ")[0].split("\n")[-1])[0])
    # recieved = int(re.findall("\d+",ping_result[0].decode('utf-8').split("transmitted, ")[1].split(",")[0])[0])

    packet_loss = int(re.findall("\d+%", ping_result[0].decode('utf-8'))[0].replace("%", "")) / 100
    return latency, packet_loss

BASE_SERVER_URL = "http://129.100.17.101:5000/"
PING_URL = "129.100.17.101"
def parse_args():
    parser = argparse.ArgumentParser(
        description="Sharing Files to the server"
    )

    parser.add_argument(
        "--load",
        type=str,
        default="low",
    )

    return parser.parse_args()

import time
if __name__ == "__main__":
    args = parse_args()

    p = Popen(['python', 'file_sharing.py', "--load", args.load])

    upload_latencies = []
    download_latencies = []
    packets_lost = []
    start = time.time()
    time_index = 1
    time_checkpoint = 30 #Number of seconds it will update the database with

    start =time.time()

    total_upload_bytes = 0
    total_download_bytes = 0
    sent_bytes = 0
    recieved_bytes = 0

    while True:
        # Measure Throughput
        old_throughput_download, old_throughput_upload = calculate_throughput(0, 0)

        time.sleep(1)
        mbs_per_second_download, mbs_per_second_upload = calculate_throughput(old_throughput_download, old_throughput_upload)


        time.sleep(1)

        # packetloss = get_packet_loss(PING_URL)
        latency, packet_loss = get_latency_and_packet_loss(BASE_SERVER_URL + "/get_latency_and_packet_loss")
        download_latencies.append(latency)
        packets_lost.append(packet_loss)
        time_index+=1
        print(time_index)
        if time_index%time_checkpoint==0:
            print("checkpoint")
            #Get Bandwidth
            bandwidth_download, bandwidth_upload = get_bandwidth()
            #Calculate Jitter
            jitter = calculate_jitter(download_latencies)

            #Measure Packet Loss

            #Get Coordinates
            latitude, longitude = geocoder.ip('me').latlng
            cursor.execute(f"""
                insert into qosmetrics(bandwidth_download, bandwidth_upload, throughput_download, throughput_upload, latency_download, jitter_download, packetloss_download, latitude, longitude, load)
                values({bandwidth_download}, {bandwidth_upload}, {mbs_per_second_download}, {mbs_per_second_upload}, {latency}, {jitter}, {np.mean(packets_lost)}, {latitude}, {longitude}, '{args.load}')
            """)

            connection.commit()
            print("inserted")
            print(time.time() - start)
            start = time.time()

            total_upload_bytes = 0
            total_download_bytes = 0
            sent_bytes = 0
            recieved_bytes = 0
            download_latencies = []


